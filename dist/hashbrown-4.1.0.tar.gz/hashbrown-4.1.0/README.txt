####################################################
Hashbrown: A Runge Kutta 4-th Order Program by Hyungho Choi
####################################################

-Please follow the instruction carefully (since I also do not know what could go wrong)

0. Setup
	This Program uses two additional modules that is not included in the original python package.

The programs are matplotlib (for plotting directly from python) and openpyxl (for accessing excel from python)

If you have pip installed in your version of python, this should be easy

1. Open the command prompt (type "cmd" on your start menu
2. Type the following lines and hit enter (one by one)
##########################################################################

python -m pip install -U pip

pip install matplotlib

pip install openpyxl

#########################################################################
Executing each line will either load alot of things or say the requirement is already satisfied
It is fine unless any error message shows up

-If this does not work for you, get some help at
https://openpyxl.readthedocs.io/en/stable/#
https://matplotlib.org/users/installing.html

3. Copy the [hashbrown] folder and paste it into the python site-packages
directory: (...)\Python35\Lib\site-packages
(example: C:\Python35\Lib\site-packages)

installation is complete. You could take a Look at the (_Demo) for a quick lookaround
take a look at the documentation for a quick tutorial

#############################################################################
